{{/*
=============================================================================
  helm-operator — Named Templates
=============================================================================
*/}}

{{- define "helm-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "helm-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name (include "helm-operator.name" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/* App namespace — shared with product-cloud */}}
{{- define "helm-operator.namespace" -}}
product
{{- end }}

{{/* Chart label */}}
{{- define "helm-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Common labels */}}
{{- define "helm-operator.commonLabels" -}}
helm.sh/chart: {{ include "helm-operator.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}

{{/* ── Operator ──────────────────────────────────────────────────────────── */}}

{{- define "helm-operator.operator.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.operator.name }}
app.kubernetes.io/component: operator
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "helm-operator.operator.labels" -}}
{{ include "helm-operator.commonLabels" . }}
{{ include "helm-operator.operator.selectorLabels" . }}
{{- end }}

{{/* Operator image — auto-computes dockerhubUsername/operator.name:tag */}}
{{- define "helm-operator.operator.image" -}}
{{- $repo := .Values.operator.image.repository -}}
{{- if not $repo -}}
{{- $repo = printf "%s/%s" .Values.global.dockerhubUsername .Values.operator.name -}}
{{- end -}}
{{- printf "%s:%s" $repo .Values.operator.image.tag -}}
{{- end }}

{{/* Operator image pull policy — falls back to global */}}
{{- define "helm-operator.operator.imagePullPolicy" -}}
{{- if .Values.operator.image.pullPolicy -}}
{{ .Values.operator.image.pullPolicy }}
{{- else -}}
{{ .Values.global.imagePullPolicy }}
{{- end -}}
{{- end }}

{{/* Operator service account name */}}
{{- define "helm-operator.operator.serviceAccountName" -}}
{{- if .Values.operator.serviceAccount.create -}}
{{- default (printf "%s-operator" (include "helm-operator.fullname" .)) .Values.operator.serviceAccount.name }}
{{- else -}}
{{- default "default" .Values.operator.serviceAccount.name }}
{{- end -}}
{{- end }}
