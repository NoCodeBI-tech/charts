#!/usr/bin/env bash
# =============================================================================
#  bootstrap.sh — product-cloud cluster setup
#  Target: CLIENT MULTI-NODE KUBEADM CLUSTER (not internet accessible)
#  Run ONCE from the control-plane node before deploying the product-cloud chart.
#
#  What it does:
#    1. Installs Rancher local-path-provisioner (dynamic PVC support)
#    2. Installs Traefik (DaemonSet + hostPort 80/443 on every worker node)
#    3. Installs mkcert and generates root CA
#    4. Installs cert-manager
#    5. Creates mkcert CA secret in cert-manager namespace
#    6. Creates ClusterIssuer "mkcert-ca-issuer" (CA type)
#    7. Creates mkcert-ca generic secret in product namespace (for pod HTTPS trust)
#
#  After this script:
#    - cert-manager auto-creates TLS secrets from Certificate CRDs in Helm charts
#    - No more manual "mkcert <domain>" per app install
#
#  Prerequisites:
#    - kubectl configured and pointing to the kubeadm cluster
#    - helm v3.8+ installed on the control-plane node
#    - Worker nodes have ports 80 and 443 open (firewall/iptables)
#
#  /etc/hosts on each client machine (laptop/desktop accessing the app):
#    <WORKER-NODE-IP>  local-product.nocodebi.io
#
#  Usage:
#    chmod +x charts/product-cloud/cluster-infra/bootstrap.sh
#    ./charts/product-cloud/cluster-infra/bootstrap.sh
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOMAIN="local-product.nocodebi.io"
NAMESPACE="product"
CERT_MANAGER_VERSION="v1.17.2"
CLUSTER_ISSUER_NAME="mkcert-ca-issuer"
CA_SECRET_NAME="mkcert-ca-secret"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
step()  { echo -e "${CYAN}[STEP]${NC}  $*"; }

# ── 0. Pre-flight checks ──────────────────────────────────────────────────────
info "Checking prerequisites..."
command -v kubectl >/dev/null 2>&1 || { echo "kubectl not found. Aborting."; exit 1; }
command -v helm    >/dev/null 2>&1 || { echo "helm not found. Aborting."; exit 1; }
kubectl cluster-info --request-timeout=5s >/dev/null 2>&1 || { echo "kubectl cannot reach cluster. Aborting."; exit 1; }

NODE_COUNT=$(kubectl get nodes --no-headers 2>/dev/null | wc -l | tr -d ' ')
info "Cluster nodes detected: ${NODE_COUNT}"
if [[ "${NODE_COUNT}" -lt 2 ]]; then
  warn "Only ${NODE_COUNT} node found. Production deployment (replicaCount:2 + required anti-affinity) needs >=2 worker nodes."
fi
info "Prerequisites OK."

# ── 1. local-path-provisioner ─────────────────────────────────────────────────
step "Step 1/6 — Installing local-path-provisioner..."
if kubectl get storageclass local-path >/dev/null 2>&1; then
  warn "StorageClass 'local-path' already exists. Skipping."
else
  kubectl apply -f "${SCRIPT_DIR}/../../../central-cloud/cluster-infra/00-storage/local-path-provisioner.yaml"
  kubectl rollout status deployment/local-path-provisioner -n local-path-storage --timeout=120s
  info "local-path-provisioner ready."
fi

# ── 2. Traefik ────────────────────────────────────────────────────────────────
step "Step 2/6 — Installing Traefik (DaemonSet + hostPort 80/443 on worker nodes)..."
helm repo add traefik https://traefik.github.io/charts --force-update
helm upgrade -i traefik traefik/traefik \
  -f "${SCRIPT_DIR}/02-traefik/values.yaml" \
  -n traefik-system --create-namespace \
  --wait --timeout=5m

kubectl label namespace traefik-system kubernetes.io/metadata.name=traefik-system --overwrite
info "Traefik ready."

# ── 3. mkcert — install & generate root CA ────────────────────────────────────
step "Step 3/6 — Installing mkcert on control-plane..."
if command -v mkcert >/dev/null 2>&1; then
  warn "mkcert already installed. Skipping binary install."
else
  MKCERT_VERSION="v1.4.4"
  ARCH=$(uname -m)
  if [[ "$ARCH" == "x86_64" ]]; then
    MKCERT_BIN="mkcert-${MKCERT_VERSION}-linux-amd64"
  else
    MKCERT_BIN="mkcert-${MKCERT_VERSION}-linux-arm64"
  fi
  curl -Lo /usr/local/bin/mkcert \
    "https://github.com/FiloSottile/mkcert/releases/download/${MKCERT_VERSION}/${MKCERT_BIN}"
  chmod +x /usr/local/bin/mkcert
fi

# Install mkcert root CA into the control-plane's trust store
mkcert -install
CAROOT=$(mkcert -CAROOT)
info "mkcert root CA stored at: ${CAROOT}"

# Save CA cert for distribution to client machines
cp "${CAROOT}/rootCA.pem" "${SCRIPT_DIR}/mkcert-rootCA.pem"
info "Root CA saved to: ${SCRIPT_DIR}/mkcert-rootCA.pem"

# ── 4. cert-manager ───────────────────────────────────────────────────────────
step "Step 4/6 — Installing cert-manager ${CERT_MANAGER_VERSION}..."
if kubectl get deployment cert-manager -n cert-manager >/dev/null 2>&1; then
  warn "cert-manager already installed. Skipping."
else
  helm repo add jetstack https://charts.jetstack.io --force-update
  helm upgrade -i cert-manager jetstack/cert-manager \
    --namespace cert-manager --create-namespace \
    --version "${CERT_MANAGER_VERSION}" \
    --set crds.enabled=true \
    --wait --timeout=5m
  info "cert-manager ready."
fi

# ── 5. Create mkcert CA secret in cert-manager namespace ──────────────────────
step "Step 5/6 — Creating mkcert CA secret for cert-manager..."
kubectl create secret tls "${CA_SECRET_NAME}" \
  --cert="${CAROOT}/rootCA.pem" \
  --key="${CAROOT}/rootCA-key.pem" \
  -n cert-manager \
  --dry-run=client -o yaml | kubectl apply -f -
info "CA secret '${CA_SECRET_NAME}' created in cert-manager namespace."

# ── 6. Create ClusterIssuer ───────────────────────────────────────────────────
step "Step 6/6 — Creating ClusterIssuer '${CLUSTER_ISSUER_NAME}'..."
kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: ${CLUSTER_ISSUER_NAME}
spec:
  ca:
    secretName: ${CA_SECRET_NAME}
EOF
info "ClusterIssuer '${CLUSTER_ISSUER_NAME}' created."

# Wait for ClusterIssuer to become Ready
info "Waiting for ClusterIssuer to become Ready..."
for i in $(seq 1 30); do
  READY=$(kubectl get clusterissuer "${CLUSTER_ISSUER_NAME}" -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "")
  if [[ "${READY}" == "True" ]]; then
    info "ClusterIssuer '${CLUSTER_ISSUER_NAME}' is Ready."
    break
  fi
  sleep 2
done

# ── Create product namespace + mkcert-ca secret for pod HTTPS trust ───────────
info "Creating product namespace and mkcert-ca secret for pod outbound HTTPS trust..."
kubectl create namespace "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -

kubectl create secret generic mkcert-ca \
  --from-file=rootCA.pem="${CAROOT}/rootCA.pem" \
  -n "${NAMESPACE}" \
  --dry-run=client -o yaml | kubectl apply -f -
info "mkcert-ca secret created in namespace '${NAMESPACE}'."

# ── Done — print manual steps ─────────────────────────────────────────────────
WORKER_IPS=$(kubectl get nodes -o wide --no-headers | grep -v control-plane | awk '{print $6}' | tr '\n' ' ' || echo "<worker-node-ip>")

echo ""
info "Bootstrap complete!"
echo ""
echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║  cert-manager CA Issuer is ready — TLS secrets are now AUTO-GENERATED  ║"
echo "║  No more manual 'mkcert <domain>' needed per app install!              ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
echo ""
echo "  ClusterIssuer: ${CLUSTER_ISSUER_NAME}"
echo "  CA Secret:     ${CA_SECRET_NAME} (in cert-manager namespace)"
echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║  MANUAL STEPS required on every client machine (laptop/desktop) ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
echo "  1. Copy mkcert root CA to each client machine and trust it:"
echo ""
echo "     # Linux"
echo "     sudo cp mkcert-rootCA.pem /usr/local/share/ca-certificates/mkcert-rootCA.crt"
echo "     sudo update-ca-certificates"
echo ""
echo "     # macOS"
echo "     sudo security add-trusted-cert -d -r trustRoot \\"
echo "       -k /Library/Keychains/System.keychain mkcert-rootCA.pem"
echo ""
echo "     # Windows (run as Administrator)"
echo "     certutil -addstore -f \"ROOT\" mkcert-rootCA.pem"
echo ""
echo "  2. Add to /etc/hosts (or C:\\Windows\\System32\\drivers\\etc\\hosts):"
echo ""
echo "     ${WORKER_IPS}  ${DOMAIN}"
echo ""
echo "     (use any worker node IP — Traefik DaemonSet runs on all workers)"
echo ""
echo "  3. Deploy product-cloud chart:"
echo ""
echo "     helm upgrade -i product-cloud charts/product-cloud \\"
echo "       -f charts/product-cloud/values.yaml \\"
echo "       -f charts/product-cloud/values-prod.yaml \\"
echo "       --set server.secrets.jwtSecret=<SAME_AS_CENTRAL> \\"
echo "       --set server.secrets.encryptionSecret=<SAME_AS_CENTRAL> \\"
echo "       --set server.secrets.googleClientId=<SECRET> \\"
echo "       --set server.secrets.googleClientSecret=<SECRET> \\"
echo "       --set server.secrets.chartRepoUrl=<URL> \\"
echo "       --set server.secrets.googleRedirectUri=<URL> \\"
echo "       -n product --create-namespace"
echo ""
echo "  4. Verify:"
echo "     kubectl get certificate -n product"
echo "     kubectl get secret product-tls -n product"
echo "     kubectl get all -n product"
echo "     kubectl get ingressroute -n product"
echo ""
echo "  5. Open in browser: https://${DOMAIN}"
echo ""
echo "  NOTE: JWT_SECRET and ENCRYPTION_SECRET must be IDENTICAL to"
echo "        the values used when deploying central-cloud."
echo ""
