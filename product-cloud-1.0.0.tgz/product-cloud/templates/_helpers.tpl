{{/*
=============================================================================
  product-cloud — Named Templates
=============================================================================
*/}}

{{- define "product-cloud.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "product-cloud.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name (include "product-cloud.name" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/* App namespace */}}
{{- define "product-cloud.namespace" -}}
product
{{- end }}

{{/* Chart label */}}
{{- define "product-cloud.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Common labels */}}
{{- define "product-cloud.commonLabels" -}}
helm.sh/chart: {{ include "product-cloud.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}

{{/* ── Server ──────────────────────────────────────────────────────────── */}}

{{- define "product-cloud.server.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.server.name }}
app.kubernetes.io/component: server
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "product-cloud.server.labels" -}}
{{ include "product-cloud.commonLabels" . }}
{{ include "product-cloud.server.selectorLabels" . }}
{{- end }}

{{/* Server image — auto-computes dockerhubUsername/server.name:tag */}}
{{- define "product-cloud.server.image" -}}
{{- $repo := .Values.server.image.repository -}}
{{- if not $repo -}}
{{- $repo = printf "%s/%s" .Values.global.dockerhubUsername .Values.server.name -}}
{{- end -}}
{{- printf "%s:%s" $repo .Values.server.image.tag -}}
{{- end }}

{{/* Server image pull policy — falls back to global */}}
{{- define "product-cloud.server.imagePullPolicy" -}}
{{- if .Values.server.image.pullPolicy -}}
{{ .Values.server.image.pullPolicy }}
{{- else -}}
{{ .Values.global.imagePullPolicy }}
{{- end -}}
{{- end }}

{{/* Server service account name */}}
{{- define "product-cloud.server.serviceAccountName" -}}
{{- if .Values.server.serviceAccount.create -}}
{{- default (printf "%s-server" (include "product-cloud.fullname" .)) .Values.server.serviceAccount.name }}
{{- else -}}
{{- default "default" .Values.server.serviceAccount.name }}
{{- end -}}
{{- end }}
