#!/usr/bin/env bash
# =============================================================================
#  bootstrap.sh — central-cloud cluster setup (kubeadm, internet accessible)
#  Run ONCE on a freshly initialised kubeadm cluster before deploying charts.
#
#  What it does:
#    1. Installs Rancher local-path-provisioner (dynamic PVC support)
#    2. Installs cert-manager (TLS certificate automation)
#    3. Installs Traefik (DaemonSet + hostPort 80/443 ingress controller)
#    4. Labels key namespaces for NetworkPolicy selectors
#
#  Prerequisites:
#    - kubectl configured and pointing to your kubeadm cluster
#    - helm v3.8+ installed
#    - Ports 80 and 443 open on the node's firewall / security group
#
#  Usage:
#    chmod +x charts/central-cloud/cluster-infra/bootstrap.sh
#    ./charts/central-cloud/cluster-infra/bootstrap.sh
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }

# ── 0. Pre-flight checks ──────────────────────────────────────────────────────
info "Checking prerequisites..."
command -v kubectl >/dev/null 2>&1 || { echo "kubectl not found. Aborting."; exit 1; }
command -v helm    >/dev/null 2>&1 || { echo "helm not found. Aborting."; exit 1; }
kubectl cluster-info --request-timeout=5s >/dev/null 2>&1 || { echo "kubectl cannot reach cluster. Aborting."; exit 1; }
info "Prerequisites OK."

# ── 1. Local-path provisioner ─────────────────────────────────────────────────
info "Step 1/4 — Installing local-path-provisioner..."
kubectl apply -f "${SCRIPT_DIR}/00-storage/local-path-provisioner.yaml"
kubectl rollout status deployment/local-path-provisioner -n local-path-storage --timeout=120s
info "local-path-provisioner ready."

# ── 2. cert-manager ──────────────────────────────────────────────────────────
info "Step 2/4 — Installing cert-manager..."
helm repo add jetstack https://charts.jetstack.io --force-update
helm upgrade -i cert-manager jetstack/cert-manager \
  -f "${SCRIPT_DIR}/01-cert-manager/values.yaml" \
  -n cert-manager --create-namespace \
  --wait --timeout=5m
info "cert-manager ready."

# ── 3. Traefik ────────────────────────────────────────────────────────────────
info "Step 3/4 — Installing Traefik (DaemonSet + hostPort 80/443)..."
helm repo add traefik https://traefik.github.io/charts --force-update
helm upgrade -i traefik traefik/traefik \
  -f "${SCRIPT_DIR}/02-traefik/values.yaml" \
  -n traefik-system --create-namespace \
  --wait --timeout=5m
info "Traefik ready."

# ── 4. Label namespaces for NetworkPolicy ─────────────────────────────────────
info "Step 4/4 — Labelling namespaces for NetworkPolicy selectors..."
kubectl label namespace traefik-system kubernetes.io/metadata.name=traefik-system --overwrite
kubectl label namespace cert-manager    kubernetes.io/metadata.name=cert-manager    --overwrite
info "Namespace labels applied."

# ── Done ─────────────────────────────────────────────────────────────────────
echo ""
info "Bootstrap complete! Next steps:"
echo ""
echo "  1. Deploy central-cloud chart (staging TLS first):"
echo "     helm upgrade -i central-cloud charts/central-cloud \\"
echo "       -f charts/central-cloud/values.yaml \\"
echo "       -f charts/central-cloud/values-prod.yaml \\"
echo "       --set server.secrets.jwtSecret=<SECRET> \\"
echo "       --set server.secrets.encryptionSecret=<SECRET> \\"
echo "       --set server.secrets.dbPassword=<SECRET> \\"
echo "       --set server.secrets.mailPassword=<SECRET> \\"
echo "       --set postgres.secrets.password=<SECRET> \\"
echo "       -n central --create-namespace"
echo ""
echo "  2. Verify staging cert:"
echo "     kubectl describe certificate central-tls -n central"
echo ""
echo "  3. Once staging cert is READY, switch to production:"
echo "     helm upgrade central-cloud charts/central-cloud \\"
echo "       -f charts/central-cloud/values.yaml \\"
echo "       -f charts/central-cloud/values-prod.yaml \\"
echo "       --set traefik.clusterIssuer.staging.enabled=false \\"
echo "       --set traefik.clusterIssuer.production.enabled=true \\"
echo "       --set traefik.activeIssuer=letsencrypt-prod \\"
echo "       --set server.secrets.jwtSecret=<SECRET> \\"
echo "       ... (same secrets)"
echo ""
