{{/*
=============================================================================
  central-cloud — Named Templates
=============================================================================
*/}}

{{/* Chart name */}}
{{- define "central-cloud.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Fullname: release-chart, max 63 chars */}}
{{- define "central-cloud.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name (include "central-cloud.name" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/* App namespace */}}
{{- define "central-cloud.namespace" -}}
central
{{- end }}

{{/* Data namespace */}}
{{- define "central-cloud.dataNamespace" -}}
central-data
{{- end }}

{{/* Chart label */}}
{{- define "central-cloud.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Common labels */}}
{{- define "central-cloud.commonLabels" -}}
helm.sh/chart: {{ include "central-cloud.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}

{{/* ── Server ──────────────────────────────────────────────────────────── */}}

{{- define "central-cloud.server.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.server.name }}
app.kubernetes.io/component: server
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "central-cloud.server.labels" -}}
{{ include "central-cloud.commonLabels" . }}
{{ include "central-cloud.server.selectorLabels" . }}
{{- end }}

{{/* Server image — auto-computes dockerhubUsername/server.name:tag */}}
{{- define "central-cloud.server.image" -}}
{{- $repo := .Values.server.image.repository -}}
{{- if not $repo -}}
{{- $repo = printf "%s/%s" .Values.global.dockerhubUsername .Values.server.name -}}
{{- end -}}
{{- printf "%s:%s" $repo .Values.server.image.tag -}}
{{- end }}

{{/* Server image pull policy — falls back to global */}}
{{- define "central-cloud.server.imagePullPolicy" -}}
{{- if .Values.server.image.pullPolicy -}}
{{ .Values.server.image.pullPolicy }}
{{- else -}}
{{ .Values.global.imagePullPolicy }}
{{- end -}}
{{- end }}

{{/* Server service account name */}}
{{- define "central-cloud.server.serviceAccountName" -}}
{{- if .Values.server.serviceAccount.create -}}
{{- default (printf "%s-server" (include "central-cloud.fullname" .)) .Values.server.serviceAccount.name }}
{{- else -}}
{{- default "default" .Values.server.serviceAccount.name }}
{{- end -}}
{{- end }}

{{/* ── Postgres ─────────────────────────────────────────────────────────── */}}

{{- define "central-cloud.postgres.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.postgres.name }}
app.kubernetes.io/component: postgres
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "central-cloud.postgres.labels" -}}
{{ include "central-cloud.commonLabels" . }}
{{ include "central-cloud.postgres.selectorLabels" . }}
{{- end }}

{{- define "central-cloud.postgres.image" -}}
{{- printf "%s:%s" .Values.postgres.image.repository .Values.postgres.image.tag -}}
{{- end }}
