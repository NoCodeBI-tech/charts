#!/usr/bin/env bash
# =============================================================================
#  install-app.sh — Per-appserver install helper
#  Target: CLIENT MULTI-NODE KUBEADM CLUSTER (same cluster as product-cloud)
#
#  Run ONCE per app install, BEFORE helm install.
#  Assumes product-cloud/cluster-infra/bootstrap.sh already ran
#  (mkcert + cert-manager + ClusterIssuer already installed).
#
#  What it does:
#    1. Creates namespace {appName}
#    2. Creates mkcert-ca generic secret in {appName} namespace
#       (for pod outbound HTTPS trust)
#
#  TLS certificate is auto-created by cert-manager via the Certificate CRD
#  in the Helm chart — no manual mkcert or kubectl create secret tls needed.
#
#  Usage:
#    chmod +x charts/appserver/cluster-infra/install-app.sh
#    ./charts/appserver/cluster-infra/install-app.sh <appName>
#
#  Example:
#    ./charts/appserver/cluster-infra/install-app.sh acme
#    → namespace:  acme
#    → domain:     acme.nocodebi.io (TLS auto-created by cert-manager)
#    → CA secret:  mkcert-ca (for pod HTTPS trust)
# =============================================================================

set -euo pipefail

# ── Args ──────────────────────────────────────────────────────────────────────
APP_NAME="${1:-}"
if [[ -z "${APP_NAME}" ]]; then
  echo "Usage: $0 <appName>"
  echo "  Example: $0 acme"
  exit 1
fi

DOMAIN="${APP_NAME}.nocodebi.io"
NAMESPACE="${APP_NAME}"
CA_SECRET="mkcert-ca"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
step()  { echo -e "${CYAN}[STEP]${NC}  $*"; }

# ── 0. Pre-flight ─────────────────────────────────────────────────────────────
info "Installing appserver: ${APP_NAME}"
info "Domain: ${DOMAIN}"

command -v kubectl >/dev/null 2>&1 || { echo "kubectl not found. Aborting."; exit 1; }
command -v mkcert  >/dev/null 2>&1 || {
  echo "mkcert not found. Run product-cloud/cluster-infra/bootstrap.sh first."
  exit 1
}
kubectl cluster-info --request-timeout=5s >/dev/null 2>&1 || { echo "kubectl cannot reach cluster. Aborting."; exit 1; }

# Verify ClusterIssuer exists
if ! kubectl get clusterissuer mkcert-ca-issuer >/dev/null 2>&1; then
  echo "ClusterIssuer 'mkcert-ca-issuer' not found. Run product-cloud/cluster-infra/bootstrap.sh first."
  exit 1
fi

CAROOT=$(mkcert -CAROOT)

# ── 1. Create namespace ───────────────────────────────────────────────────────
step "Step 1/2 — Creating namespace '${NAMESPACE}'..."
kubectl create namespace "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -
info "Namespace '${NAMESPACE}' ready."

# ── 2. Create mkcert-ca secret (for pod outbound HTTPS trust) ─────────────────
step "Step 2/2 — Creating mkcert-ca secret in namespace '${NAMESPACE}'..."
kubectl create secret generic "${CA_SECRET}" \
  --from-file=rootCA.pem="${CAROOT}/rootCA.pem" \
  -n "${NAMESPACE}" \
  --dry-run=client -o yaml | kubectl apply -f -
info "mkcert-ca secret created in namespace '${NAMESPACE}'."

# ── Done ──────────────────────────────────────────────────────────────────────
WORKER_IPS=$(kubectl get nodes -o wide --no-headers | grep -v control-plane | awk '{print $6}' | tr '\n' ' ' || echo "<worker-node-ip>")

echo ""
info "Secrets ready for appserver '${APP_NAME}'!"
echo ""
echo "╔═══════════════════════════════════════════════════════════════════════╗"
echo "║  TLS certificate will be auto-created by cert-manager on helm install ║"
echo "╚═══════════════════════════════════════════════════════════════════════╝"
echo ""
echo "  1. Add to /etc/hosts (or C:\\Windows\\System32\\drivers\\etc\\hosts)"
echo "     on EVERY machine that needs browser access:"
echo ""
echo "     ${WORKER_IPS}  ${DOMAIN}"
echo ""
echo "     (use any worker node IP — Traefik DaemonSet runs on all workers)"
echo ""
echo "  2. Run helm install:"
echo ""
echo "     helm install ${APP_NAME} charts/appserver \\"
echo "       --set appName=${APP_NAME} \\"
echo "       --set app.appId=<UUID> \\"
echo "       --set app.stageId=<UUID> \\"
echo "       --set secrets.jwtSecret=<SECRET> \\"
echo "       --set secrets.encryptionSecret=<SECRET> \\"
echo "       --set secrets.dbPassword=<PASSWORD> \\"
echo "       --set connector.config.coreJarUrl=<URL> \\"
echo "       --set connector.config.m2ZipUrl=<URL> \\"
echo "       -n ${NAMESPACE}"
echo ""
echo "  3. Verify:"
echo "     kubectl get certificate -n ${NAMESPACE}"
echo "     kubectl get secret ${APP_NAME}-tls -n ${NAMESPACE}"
echo "     kubectl get all -n ${NAMESPACE}"
echo "     kubectl get ingressroute -n ${NAMESPACE}"
echo ""
echo "  4. Open in browser: https://${DOMAIN}"
echo ""
