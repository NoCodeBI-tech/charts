{{/*
=============================================================================
  appserver — Named Templates (multi-install chart)
  appName drives: namespace, resource prefix, domain, TLS secret
=============================================================================
*/}}

{{/* ── Identity ──────────────────────────────────────────────────────── */}}

{{- define "appserver.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "appserver.fullname" -}}
{{- required "appName is required" .Values.appName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "appserver.namespace" -}}
{{- required "appName is required" .Values.appName }}
{{- end }}

{{- define "appserver.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* ── Common labels ──────────────────────────────────────────────────── */}}

{{- define "appserver.commonLabels" -}}
helm.sh/chart: {{ include "appserver.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/part-of: {{ include "appserver.fullname" . }}
{{- end }}

{{/* ── Per-component labels & selectors ─────────────────────────────── */}}

{{/* Generic selector labels — pass component name */}}
{{- define "appserver.selectorLabels" -}}
app.kubernetes.io/name: {{ .name }}
app.kubernetes.io/component: {{ .component }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
{{- end }}

{{/* ── Gateway ─────────────────────────────────────────────────────── */}}
{{- define "appserver.gateway.selectorLabels" -}}
{{ include "appserver.selectorLabels" (dict "name" .Values.gateway.name "component" "gateway" "root" .) }}
{{- end }}
{{- define "appserver.gateway.labels" -}}
{{ include "appserver.commonLabels" . }}
{{ include "appserver.gateway.selectorLabels" . }}
{{- end }}
{{- define "appserver.gateway.image" -}}
{{- $repo := .Values.gateway.image.repository -}}
{{- if not $repo }}{{- $repo = printf "%s/%s" .Values.global.dockerhubUsername .Values.gateway.name -}}{{- end -}}
{{- printf "%s:%s" $repo .Values.gateway.image.tag -}}
{{- end }}
{{- define "appserver.gateway.imagePullPolicy" -}}
{{- if .Values.gateway.image.pullPolicy }}{{ .Values.gateway.image.pullPolicy }}{{- else }}{{ .Values.global.imagePullPolicy }}{{- end -}}
{{- end }}
{{- define "appserver.gateway.serviceAccountName" -}}
{{- if .Values.gateway.serviceAccount.create -}}
{{- default (printf "%s-gateway" (include "appserver.fullname" .)) .Values.gateway.serviceAccount.name }}
{{- else -}}
{{- default "default" .Values.gateway.serviceAccount.name }}
{{- end -}}
{{- end }}

{{/* ── Config ──────────────────────────────────────────────────────── */}}
{{- define "appserver.config.selectorLabels" -}}
{{ include "appserver.selectorLabels" (dict "name" .Values.config.name "component" "config" "root" .) }}
{{- end }}
{{- define "appserver.config.labels" -}}
{{ include "appserver.commonLabels" . }}
{{ include "appserver.config.selectorLabels" . }}
{{- end }}
{{- define "appserver.config.image" -}}
{{- $repo := .Values.config.image.repository -}}
{{- if not $repo }}{{- $repo = printf "%s/%s" .Values.global.dockerhubUsername .Values.config.name -}}{{- end -}}
{{- printf "%s:%s" $repo .Values.config.image.tag -}}
{{- end }}
{{- define "appserver.config.imagePullPolicy" -}}
{{- if .Values.config.image.pullPolicy }}{{ .Values.config.image.pullPolicy }}{{- else }}{{ .Values.global.imagePullPolicy }}{{- end -}}
{{- end }}
{{- define "appserver.config.serviceAccountName" -}}
{{- if .Values.config.serviceAccount.create -}}
{{- default (printf "%s-config" (include "appserver.fullname" .)) .Values.config.serviceAccount.name }}
{{- else -}}
{{- default "default" .Values.config.serviceAccount.name }}
{{- end -}}
{{- end }}

{{/* ── Connector ───────────────────────────────────────────────────── */}}
{{- define "appserver.connector.selectorLabels" -}}
{{ include "appserver.selectorLabels" (dict "name" .Values.connector.name "component" "connector" "root" .) }}
{{- end }}
{{- define "appserver.connector.labels" -}}
{{ include "appserver.commonLabels" . }}
{{ include "appserver.connector.selectorLabels" . }}
{{- end }}
{{- define "appserver.connector.image" -}}
{{- $repo := .Values.connector.image.repository -}}
{{- if not $repo }}{{- $repo = printf "%s/%s" .Values.global.dockerhubUsername .Values.connector.name -}}{{- end -}}
{{- printf "%s:%s" $repo .Values.connector.image.tag -}}
{{- end }}
{{- define "appserver.connector.imagePullPolicy" -}}
{{- if .Values.connector.image.pullPolicy }}{{ .Values.connector.image.pullPolicy }}{{- else }}{{ .Values.global.imagePullPolicy }}{{- end -}}
{{- end }}
{{- define "appserver.connector.serviceAccountName" -}}
{{- if .Values.connector.serviceAccount.create -}}
{{- default (printf "%s-connector" (include "appserver.fullname" .)) .Values.connector.serviceAccount.name }}
{{- else -}}
{{- default "default" .Values.connector.serviceAccount.name }}
{{- end -}}
{{- end }}

{{/* ── Workflow ─────────────────────────────────────────────────────── */}}
{{- define "appserver.workflow.selectorLabels" -}}
{{ include "appserver.selectorLabels" (dict "name" .Values.workflow.name "component" "workflow" "root" .) }}
{{- end }}
{{- define "appserver.workflow.labels" -}}
{{ include "appserver.commonLabels" . }}
{{ include "appserver.workflow.selectorLabels" . }}
{{- end }}
{{- define "appserver.workflow.image" -}}
{{- $repo := .Values.workflow.image.repository -}}
{{- if not $repo }}{{- $repo = printf "%s/%s" .Values.global.dockerhubUsername .Values.workflow.name -}}{{- end -}}
{{- printf "%s:%s" $repo .Values.workflow.image.tag -}}
{{- end }}
{{- define "appserver.workflow.imagePullPolicy" -}}
{{- if .Values.workflow.image.pullPolicy }}{{ .Values.workflow.image.pullPolicy }}{{- else }}{{ .Values.global.imagePullPolicy }}{{- end -}}
{{- end }}
{{- define "appserver.workflow.serviceAccountName" -}}
{{- if .Values.workflow.serviceAccount.create -}}
{{- default (printf "%s-workflow" (include "appserver.fullname" .)) .Values.workflow.serviceAccount.name }}
{{- else -}}
{{- default "default" .Values.workflow.serviceAccount.name }}
{{- end -}}
{{- end }}

{{/* ── View ────────────────────────────────────────────────────────── */}}
{{- define "appserver.view.selectorLabels" -}}
{{ include "appserver.selectorLabels" (dict "name" .Values.view.name "component" "view" "root" .) }}
{{- end }}
{{- define "appserver.view.labels" -}}
{{ include "appserver.commonLabels" . }}
{{ include "appserver.view.selectorLabels" . }}
{{- end }}
{{- define "appserver.view.image" -}}
{{- $repo := .Values.view.image.repository -}}
{{- if not $repo }}{{- $repo = printf "%s/%s" .Values.global.dockerhubUsername .Values.view.name -}}{{- end -}}
{{- printf "%s:%s" $repo .Values.view.image.tag -}}
{{- end }}
{{- define "appserver.view.imagePullPolicy" -}}
{{- if .Values.view.image.pullPolicy }}{{ .Values.view.image.pullPolicy }}{{- else }}{{ .Values.global.imagePullPolicy }}{{- end -}}
{{- end }}
{{- define "appserver.view.serviceAccountName" -}}
{{- if .Values.view.serviceAccount.create -}}
{{- default (printf "%s-view" (include "appserver.fullname" .)) .Values.view.serviceAccount.name }}
{{- else -}}
{{- default "default" .Values.view.serviceAccount.name }}
{{- end -}}
{{- end }}

{{/* ── Query ─────────────────────────────────────────────────────── */}}
{{- define "appserver.query.selectorLabels" -}}
{{ include "appserver.selectorLabels" (dict "name" .Values.query.name "component" "query" "root" .) }}
{{- end }}
{{- define "appserver.query.labels" -}}
{{ include "appserver.commonLabels" . }}
{{ include "appserver.query.selectorLabels" . }}
{{- end }}
{{- define "appserver.query.image" -}}
{{- $repo := .Values.query.image.repository -}}
{{- if not $repo }}{{- $repo = printf "%s/%s" .Values.global.dockerhubUsername .Values.query.name -}}{{- end -}}
{{- printf "%s:%s" $repo .Values.query.image.tag -}}
{{- end }}
{{- define "appserver.query.imagePullPolicy" -}}
{{- if .Values.query.image.pullPolicy }}{{ .Values.query.image.pullPolicy }}{{- else }}{{ .Values.global.imagePullPolicy }}{{- end -}}
{{- end }}
{{- define "appserver.query.serviceAccountName" -}}
{{- if .Values.query.serviceAccount.create -}}
{{- default (printf "%s-query" (include "appserver.fullname" .)) .Values.query.serviceAccount.name }}
{{- else -}}
{{- default "default" .Values.query.serviceAccount.name }}
{{- end -}}
{{- end }}

{{/* ── Query server URL ─────────────────────────────────────────── */}}
{{- define "appserver.url.queryServer" -}}
http://{{ .Values.query.name }}:{{ .Values.query.port }}
{{- end }}

{{/* ── Postgres ─────────────────────────────────────────────────────── */}}
{{- define "appserver.postgres.selectorLabels" -}}
{{ include "appserver.selectorLabels" (dict "name" .Values.postgres.name "component" "postgres" "root" .) }}
{{- end }}
{{- define "appserver.postgres.labels" -}}
{{ include "appserver.commonLabels" . }}
{{ include "appserver.postgres.selectorLabels" . }}
{{- end }}
{{- define "appserver.postgres.image" -}}
{{- printf "%s:%s" .Values.postgres.image.repository .Values.postgres.image.tag -}}
{{- end }}

{{/* ── Redis ────────────────────────────────────────────────────────── */}}
{{- define "appserver.redis.selectorLabels" -}}
{{ include "appserver.selectorLabels" (dict "name" .Values.redis.name "component" "redis" "root" .) }}
{{- end }}
{{- define "appserver.redis.labels" -}}
{{ include "appserver.commonLabels" . }}
{{ include "appserver.redis.selectorLabels" . }}
{{- end }}

{{/* ── Doris FE ─────────────────────────────────────────────────────── */}}
{{- define "appserver.doris.fe.selectorLabels" -}}
{{ include "appserver.selectorLabels" (dict "name" .Values.doris.fe.name "component" "doris-fe" "root" .) }}
{{- end }}
{{- define "appserver.doris.fe.labels" -}}
{{ include "appserver.commonLabels" . }}
{{ include "appserver.doris.fe.selectorLabels" . }}
{{- end }}

{{/* ── Doris BE ─────────────────────────────────────────────────────── */}}
{{- define "appserver.doris.be.selectorLabels" -}}
{{ include "appserver.selectorLabels" (dict "name" .Values.doris.be.name "component" "doris-be" "root" .) }}
{{- end }}
{{- define "appserver.doris.be.labels" -}}
{{ include "appserver.commonLabels" . }}
{{ include "appserver.doris.be.selectorLabels" . }}
{{- end }}

{{/* ── Auto-computed inter-service URLs ──────────────────────────────── */}}

{{- define "appserver.url.configServer" -}}
http://{{ .Values.config.name }}:{{ .Values.config.port }}
{{- end }}

{{- define "appserver.url.connectorServer" -}}
http://{{ .Values.connector.name }}:{{ .Values.connector.port }}
{{- end }}

{{- define "appserver.url.workflowServer" -}}
http://{{ .Values.workflow.name }}:{{ .Values.workflow.port }}
{{- end }}

{{- define "appserver.url.viewServer" -}}
http://{{ .Values.view.name }}:{{ .Values.view.port }}
{{- end }}

{{- define "appserver.url.centralServer" -}}
{{ .Values.externalUrls.centralServer }}
{{- end }}

{{- define "appserver.url.productServer" -}}
{{ .Values.externalUrls.productServer }}
{{- end }}

{{/* Node.js DATABASE_URL (pg connection string) */}}
{{- define "appserver.url.database" -}}
postgresql://{{ .Values.secrets.dbUsername }}:{{ .Values.secrets.dbPassword }}@{{ .Values.postgres.name }}:{{ .Values.postgres.port }}/{{ .Values.postgres.database }}
{{- end }}

{{/* Java JDBC DATABASE_URL */}}
{{- define "appserver.url.databaseJdbc" -}}
jdbc:postgresql://{{ .Values.postgres.name }}:{{ .Values.postgres.port }}/{{ .Values.postgres.database }}
{{- end }}

{{/* Doris URL — Node.js (mysql:// protocol) */}}
{{- define "appserver.url.doris" -}}
mysql://{{ .Values.secrets.dorisUsername }}:{{ .Values.secrets.dorisPassword }}@{{ .Values.doris.fe.name }}:{{ .Values.doris.fe.ports.query }}/{{ .Values.doris.init.database }}
{{- end }}

{{/* Doris URL — JDBC */}}
{{- define "appserver.url.dorisJdbc" -}}
jdbc:mysql://{{ .Values.doris.fe.name }}:{{ .Values.doris.fe.ports.query }}/{{ .Values.doris.init.database }}
{{- end }}

{{/* ── Traefik domain & TLS ──────────────────────────────────────────── */}}

{{- define "appserver.traefik.domain" -}}
{{- if .Values.traefik.domain -}}
{{ .Values.traefik.domain }}
{{- else -}}
{{ .Values.appName }}.{{ .Values.traefik.domainSuffix }}
{{- end -}}
{{- end }}

{{- define "appserver.traefik.tlsSecretName" -}}
{{- if .Values.traefik.tlsSecretName -}}
{{ .Values.traefik.tlsSecretName }}
{{- else -}}
{{ .Values.appName }}-tls
{{- end -}}
{{- end }}
